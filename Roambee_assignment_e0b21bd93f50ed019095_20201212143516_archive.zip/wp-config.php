<?php

/**

 * The base configuration for WordPress

 *

 * The wp-config.php creation script uses this file during the

 * installation. You don't have to use the web site, you can

 * copy this file to "wp-config.php" and fill in the values.

 *

 * This file contains the following configurations:

 *

 * * MySQL settings

 * * Secret keys

 * * Database table prefix

 * * ABSPATH

 *

 * @link https://wordpress.org/support/article/editing-wp-config-php/

 *

 * @package WordPress

 */


// ** MySQL settings - You can get this info from your web host ** //

/** The name of the database for WordPress */

define( 'DB_NAME', '' );


/** MySQL database username */

define( 'DB_USER', '' );


/** MySQL database password */

define( 'DB_PASSWORD', '' );


/** MySQL hostname */

define( 'DB_HOST', '' );


/** Database Charset to use in creating database tables. */

define( 'DB_CHARSET', 'utf8mb4' );


/** The Database Collate type. Don't change this if in doubt. */

define( 'DB_COLLATE', '' );


/**#@+

 * Authentication Unique Keys and Salts.

 *

 * Change these to different unique phrases!

 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}

 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.

 *

 * @since 2.6.0

 */

define( 'AUTH_KEY',         't!w*4oYs3Z<^n?2M1f-zz9X-)qg5y5D6F|ZKWC@<G]L](dZumU^;3rTZA0<-=qk2' );

define( 'SECURE_AUTH_KEY',  ',M?@q.Fs@LFy)a9/L?,}Z=vp+3qJfV(tnNK#(g9{snEd~$vnM1)]x1VB6Z3~_f;%' );

define( 'LOGGED_IN_KEY',    'P,?Rh0TcG }MD@6RmZP`? ;7BE}`a^jg61T_f6il|cHy`cde?!4.5@/GwqTFwqFe' );

define( 'NONCE_KEY',        '#@Dp{`i?fTx|os3.UpoSV6*{=u789DC(ZuJ^UFJ`=H : EK:{KDrm^mY2S6,>p<Z' );

define( 'AUTH_SALT',        ':DyI_brHT`_8$cwf))zfFZM$8B%o:ENZ3}K])]zy(uFl$({Z/LDD%U(}^P)Y~!{e' );

define( 'SECURE_AUTH_SALT', '`Vl}AjVAEU&gBhhkV5$OOi`3fYv7J~e0e1W>^_T%DRe,,&WGCp1y3[Gss^HYNCMS' );

define( 'LOGGED_IN_SALT',   '-$QSv/)h+h0zl-ictTN*wckm:e~t{xMnM`S-OT/EyX<Qy?UZQHBU]_)6sb`bgBOA' );

define( 'NONCE_SALT',       '[T^LK=gT(H|9%xMi+r4;^<.mc5Utx#4zJ]G 16[6KsBB{<qn]d}&d/kS1_:f@4Rs' );


/**#@-*/


/**

 * WordPress Database Table prefix.

 *

 * You can have multiple installations in one database if you give each

 * a unique prefix. Only numbers, letters, and underscores please!

 */

$table_prefix = 'wp_';


/**

 * For developers: WordPress debugging mode.

 *

 * Change this to true to enable the display of notices during development.

 * It is strongly recommended that plugin and theme developers use WP_DEBUG

 * in their development environments.

 *

 * For information on other constants that can be used for debugging,

 * visit the documentation.

 *

 * @link https://wordpress.org/support/article/debugging-in-wordpress/

 */

define( 'WP_DEBUG', false );


/* That's all, stop editing! Happy publishing. */


/** Absolute path to the WordPress directory. */

if ( ! defined( 'ABSPATH' ) ) {

	define( 'ABSPATH', __DIR__ . '/' );

}


/** Sets up WordPress vars and included files. */

require_once ABSPATH . 'wp-settings.php';

